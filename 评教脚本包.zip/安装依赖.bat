@echo off
chcp 65001 >nul
echo 安装评教脚本依赖...
python -m pip install pywinauto numpy Pillow
echo.
echo 依赖安装完成。运行 "python run.py check" 自检。
pause
