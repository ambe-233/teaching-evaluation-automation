# -*- coding: utf-8 -*-
"""剩余10门：4B+6C。动态用UIA文本矩形定位等级按钮。"""
import sys, time
import os
from pywinauto import Desktop
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import auto

d=Desktop(backend='uia')
def W():
    for x in d.windows():
        try:
            if x.window_text()=='微信' and x.element_info.class_name=='Chrome_WidgetWin_0': return x
        except Exception: pass
    raise RuntimeError('no panel')
def texts():
    return [(e.element_info.control_type,e.window_text(),e) for e in W().descendants() if e.window_text()]

def pick(lv):
    # 点第一个"选择"
    sels=[e for t,n,e in texts() if t=='Text' and n=='选择' and e.rectangle().top>130]
    if not sels: return False
    r=sels[0].rectangle()
    auto.click((r.left+r.right)//2,(r.top+r.bottom)//2); time.sleep(0.45)
    # 弹窗等级按钮：用底部区 A/B/C text 矩形，X补偿
    dlg={}
    for t,n,e in texts():
        if t=='Text' and n in ('A','B','C') and e.rectangle().top>1300:
            rr=e.rectangle(); dlg[n]=(rr.left+rr.right)//2+14,(rr.top+rr.bottom)//2
    if lv not in dlg: return False
    # A/B 按钮中心在 text 右侧约+130；C 同排单独
    x,y=dlg[lv]
    if lv=='A': x+=130
    if lv=='B': x+=37
    auto.click(x,y); time.sleep(0.45)
    return True

if __name__=='__main__':
    plan=['B']*4+['C']*6
    for i,lv in enumerate(plan):
        ok=pick(lv); print(i+1,lv,ok,flush=True)
        if not ok: break
    # 统计
    rows=[]
    for t,n,e in texts():
        r=e.rectangle()
        if t=='Text' and n in ('A','B','C','选择') and r.left>900: rows.append((r.top,n))
    from collections import Counter
    print('rows',len(rows),dict(Counter(n for _,n in rows)),flush=True)
    for t,n,e in texts():
        if n=='确认并提交': print('submit',e.rectangle(),flush=True)
