# -*- coding: utf-8 -*-
"""批量选等级：18位教师按 5A+7B+6C 配额。UIA定位'选择'按钮，点弹窗等级。"""
import sys, time
import os
from pywinauto import Desktop
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import auto

d = Desktop(backend='uia')
# 等级按钮中心（实测，全屏2880x1800，窗口内坐标即屏幕坐标）
POS = {'A': (620, 1518), 'B': (940, 1518), 'C': (620, 1648)}

def W():
    for x in d.windows():
        try:
            if x.window_text()=='微信' and x.element_info.class_name=='Chrome_WidgetWin_0':
                return x
        except Exception: pass
    raise RuntimeError('no panel')

def texts():
    return [(e.element_info.control_type, e.window_text(), e) for e in W().descendants()
            if e.window_text()]

def pick_one(lv):
    sels=[e for t,n,e in texts() if t=='Text' and n=='选择']
    if not sels: return False
    e=sels[0]; r=e.rectangle()
    auto.click((r.left+r.right)//2, (r.top+r.bottom)//2)
    time.sleep(0.45)
    auto.click(*POS[lv]); time.sleep(0.45)
    return True

if __name__=='__main__':
    # 第一门已选A，剩 4A+7B+6C = 17
    plan = ['A']*4 + ['B']*7 + ['C']*6
    print('plan',len(plan),flush=True)
    for i,lv in enumerate(plan):
        ok=pick_one(lv)
        print(i+1,lv,ok,flush=True)
        if not ok: break
    sels=[e for t,n,e in texts() if t=='Text' and n=='选择']
    print('remaining',len(sels),flush=True)
    for t,n,e in texts():
        if n in ('确认并提交','取 消'): print(t,n,e.rectangle(),flush=True)
