# -*- coding: utf-8 -*-
"""评教全自动：UIA 控件定位，循环处理所有课程。"""
import sys, time
import os
from pywinauto import Desktop
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import auto

d = Desktop(backend='uia')

def win():
    for x in d.windows():
        try:
            if x.window_text() == '微信' and x.rectangle().width() > 500:
                return x
        except Exception:
            pass
    raise RuntimeError('no wechat window')

def texts(w):
    out = []
    for e in w.descendants():
        try:
            n = e.window_text()
            if n:
                out.append((e.element_info.control_type, n, e))
        except Exception:
            pass
    return out

def click_el(e):
    r = e.rectangle()
    auto.click((r.left + r.right) // 2, (r.top + r.bottom) // 2)

def find(ct, name=None, contains=None, exact=True):
    w = win()
    for t, n, e in texts(w):
        if ct and t != ct:
            continue
        if name is not None:
            if (n == name) if exact else (name in n):
                return e
        if contains is not None and contains in n:
            return e
    return None

def grade_one(level):
    """选等级并勾理由，返回是否成功。level: A/B/C"""
    w = win()
    # 找整体评价 radio（可见性无关，用 UIA select）
    radios = [(n, e) for t, n, e in texts(w) if t == 'RadioButton' and n.startswith(level)]
    if not radios:
        print('NO RADIO for', level)
        return False
    _, e = radios[0]
    try:
        e.select()
    except Exception:
        click_el(e)
    time.sleep(0.4)
    print('selected', level)

    # A/C 触发理由必填：勾一条
    if level in ('A', 'C'):
        w = win()
        cbs = [(n, e) for t, n, e in texts(w) if t == 'CheckBox' and not n.startswith('其他')]
        # A 勾第一条正面；C 勾"教学效果"（最轻）
        target = None
        if level == 'A':
            target = cbs[0][1] if cbs else None
        else:
            for n, e in cbs:
                if n.startswith('教学效果'):
                    target = e; break
            if target is None and cbs:
                target = cbs[0][1]
        if target:
            click_el(target)  # 用坐标点，UIA check() 对网页控件无效
            time.sleep(0.3)
            print('checked reason via click')

    # 滚到底让提交按钮渲染出来
    for _ in range(20):
        auto.scroll(1)
    time.sleep(0.6)
    w = win()
    sub = None
    for t, n, e in texts(w):
        ns = n.replace(' ', '')
        if t == 'Button' and ('提交' in ns or '已提交' in ns):
            sub = (n, e); break
    if not sub:
        print('NO SUBMIT BUTTON'); return False
    print('submit button:', repr(sub[0]))
    click_el(sub[1])
    time.sleep(1.2)
    return True

def confirm():
    """等待倒计时后点确认框的确定，直到出现提交成功"""
    for _ in range(6):
        w = win()
        for t, n, e in texts(w):
            if t == 'Button' and n == '确定':
                click_el(e)
                time.sleep(1.5)
                break
        # 检查成功
        w = win()
        if any(n == '提交成功' for t, n, e in texts(w)):
            return True
        time.sleep(1.0)
    return False

def next_course():
    """点下一门课程/下一位教师，返回 True 若仍有下一门"""
    w = win()
    for t, n, e in texts(w):
        if t == 'Text' and n in ('下一门课程', '下一位教师'):
            click_el(e)
            time.sleep(1.2)
            return True
    return False

def get_level():
    """读答卷提示里的等级 A/B/C；无提示则返回 None"""
    w = win()
    ts = [n for t, n, e in texts(w)]
    if '答卷提示' not in ts:
        return None
    # 等级在"评价等级："之后
    for i, n in enumerate(ts):
        if n == '评价等级：' and i + 1 < len(ts) and ts[i+1] in ('A', 'B', 'C'):
            return ts[i+1]
    return None

def close_hint():
    e = find('Button', '我知道了')
    if e:
        click_el(e)
        time.sleep(0.8)

if __name__ == '__main__':
    # 当前第七门已关提示，A 级
    import sys
    level = sys.argv[1] if len(sys.argv) > 1 else 'A'
    print('level', level)
    grade_one(level)
    confirm()
    print('confirmed')
