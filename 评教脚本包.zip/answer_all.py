# -*- coding: utf-8 -*-
"""第十周答卷全自动：逐门读等级→选评价→勾理由→提交→确认。UIA动态定位。"""
import sys, time
import os
from collections import Counter
from pywinauto import Desktop
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import auto

d = Desktop(backend='uia')
def W():
    for x in d.windows():
        try:
            if x.window_text()=='微信' and x.element_info.class_name=='Chrome_WidgetWin_0': return x
        except Exception: pass
    raise RuntimeError('no panel')
def T(): return [(e.element_info.control_type,e.window_text(),e) for e in W().descendants() if e.window_text()]
def click(e, dx=0):
    r=e.rectangle(); auto.click((r.left+r.right)//2+dx,(r.top+r.bottom)//2)
def sv(e):
    try: e.iface_scroll_item.ScrollIntoView(); time.sleep(0.35)
    except Exception: pass

def read_level():
    ts=T()
    for i,(t,n,e) in enumerate(ts):
        if n=='答卷提示':
            for j,(t2,n2,e2) in enumerate(ts):
                if n2=='评价等级：' and j+1<len(ts) and ts[j+1][1] in ('A','B','C'):
                    return ts[j+1][1]
    for t,n,e in ts:
        if n.startswith('[') and ']' in n:
            if '90,100' in n: return 'A'
            if '70,90' in n: return 'B'
            if '0,70' in n: return 'C'
    return None

def one(lv):
    # 关提示
    for t,n,e in T():
        if t=='Button' and n=='我知道了': click(e); time.sleep(0.5); break
    # 选整体评价
    r=[e for t,n,e in T() if t=='RadioButton' and n.startswith(lv)]
    if not r: return False
    sv(r[0]); click(r[0]); time.sleep(0.4)
    # 理由
    if lv in ('A','C'):
        cbs=[(n,e) for t,n,e in T() if t=='CheckBox' and not n.startswith('其他')]
        key='教学态度' if lv=='A' else '教学效果'
        tgt=next((e for n,e in cbs if n.startswith(key)), cbs[0][1] if cbs else None)
        if tgt:
            sv(tgt); rr=tgt.rectangle(); auto.click(rr.left+35,(rr.top+rr.bottom)//2); time.sleep(0.4)
    # 提交
    sub=[e for t,n,e in T() if t=='Button' and '提交' in n.replace(' ','')]
    if not sub: return False
    sv(sub[0]); click(sub[0]); time.sleep(5.3)
    # 确认
    for _ in range(4):
        cf=[e for t,n,e in T() if t=='Button' and n=='确定']
        if cf: click(cf[0]); time.sleep(1.5)
        if any(n=='提交成功' for t,n,e in T()): return True
        time.sleep(0.8)
    return any(n=='提交成功' for t,n,e in T())

def next_one():
    for t,n,e in T():
        if t=='Text' and n in ('下一门课程','下一位教师'):
            click(e); time.sleep(1.3); return n
    return None

if __name__=='__main__':
    cnt=0
    while True:
        nx=next_one()
        if not nx:
            print('NO NEXT -> maybe all done',flush=True); break
        lv=read_level(); print('course',cnt+1,'level',lv,flush=True)
        if not lv: print('no level, stop',flush=True); break
        ok=one(lv); print('  result',ok,flush=True)
        if not ok: print('FAILED, stop',flush=True); break
        cnt+=1
        if cnt>25: break
    print('done',cnt,flush=True)
