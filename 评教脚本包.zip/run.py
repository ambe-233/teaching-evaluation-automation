# -*- coding: utf-8 -*-
"""教学评教自动化 - 统一入口。

用法：
  python run.py check     # 环境自检
  python run.py select    # 批量选等级（自动读配额）
  python run.py answer    # 逐门答卷（从"提交成功"弹窗开始）
  python run.py all       # 选等级 + 答卷全流程（需先手动进到选等级页）

设计原则：全部用 UIA 控件原生操作（Invoke/Toggle/Select），不依赖屏幕坐标。
"""
import os, sys, time

# 路径：脚本所在目录
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

def check():
    """环境自检。返回 True/False。"""
    ok = True
    try:
        import pywinauto
        print('[OK] pywinauto', pywinauto.__version__)
    except ImportError:
        print('[FAIL] 缺 pywinauto → pip install pywinauto'); ok = False
    try:
        import numpy
        print('[OK] numpy', numpy.__version__)
    except ImportError:
        print('[FAIL] 缺 numpy → pip install numpy'); ok = False
    try:
        import PIL
        print('[OK] Pillow', PIL.__version__)
    except ImportError:
        print('[FAIL] 缺 Pillow → pip install Pillow'); ok = False
    if sys.platform != 'win32':
        print('[FAIL] 仅支持 Windows'); ok = False
    if ok:
        from pywinauto import Desktop
        found = False
        for w in Desktop(backend='uia').windows():
            try:
                if w.window_text() == '微信' and w.element_info.class_name == 'Chrome_WidgetWin_0':
                    print('[OK] 评教窗口已打开'); found = True; break
            except Exception:
                pass
        if not found:
            print('[FAIL] 没找到评教窗口。先在微信里打开"教学质量管理平台"问卷')
            ok = False
    return ok

# ---- UIA 基础 ----
from pywinauto import Desktop
_d = Desktop(backend='uia')

def win():
    for w in _d.windows():
        try:
            if w.window_text() == '微信' and w.element_info.class_name == 'Chrome_WidgetWin_0':
                return w
        except Exception:
            pass
    raise RuntimeError('评教窗口未找到（先打开微信里的评教页）')

def items():
    return [(e.element_info.control_type, e.window_text(), e)
            for e in win().descendants() if e.window_text()]

def find(ct, name, contains=False):
    for t, n, e in items():
        if t == ct and ((name in n) if contains else (n == name)):
            return e
    return None

def act(e, kind='invoke'):
    """优先 UIA 原生操作，失败退 click_input。都不靠坐标硬编码。"""
    try:
        if kind == 'toggle':
            e.iface_toggle.Toggle()
        elif kind == 'select':
            e.iface_selection_item.Select()
        else:
            e.iface_invoke.Invoke()
        time.sleep(0.35)
        return True
    except Exception:
        pass
    try:
        e.click_input()
        time.sleep(0.35)
        return True
    except Exception as ex:
        print('  [WARN] click failed:', ex)
        return False

def sv(e):
    try:
        e.iface_scroll_item.ScrollIntoView(); time.sleep(0.3)
    except Exception:
        pass

# ---- 批量选等级 ----
def read_quota():
    """从顶部文本读 A/B/C 剩余配额。文本形如 '0','A','4','B','6','C'。"""
    ts = [n for t, n, e in items()]
    for i, n in enumerate(ts):
        if n in ('A', 'B', 'C') and i > 0 and ts[i-1].isdigit():
            pass
    quota = {}
    for i in range(len(ts) - 1):
        if ts[i+1] in ('A', 'B', 'C') and ts[i].isdigit():
            quota[ts[i+1]] = int(ts[i])
    return quota

def select_levels():
    """自动读配额，给所有未选('选择')的课程分配等级。"""
    q = read_quota()
    if not q:
        print('[FAIL] 读不到配额。确认在"选择教师课程等级"页')
        return False
    total = sum(q.values())
    print('配额:', q, '总计', total)
    plan = []
    for lv in ('A', 'B', 'C'):
        plan += [lv] * q.get(lv, 0)
    print('分配计划:', ''.join(plan))
    for i, lv in enumerate(plan):
        sel = find('Text', '选择')
        if not sel:
            print('  没有更多"选择"，提前结束'); break
        sv(sel); act(sel)
        # 弹窗里的等级按钮：Text A/B/C
        btn = find('Text', lv)
        if not btn:
            print('  [FAIL] 找不到等级按钮', lv); return False
        sv(btn); act(btn)
        print('  %d/%d %s' % (i+1, len(plan), lv), flush=True)
    left = len([1 for t, n, e in items() if t == 'Text' and n == '选择'])
    print('剩余未选:', left)
    sub = find('Button', '确认并提交')
    if sub:
        print('请手动点"确认并提交"并检查配额，或运行: python run.py answer')
    return left == 0

# ---- 逐门答卷 ----
def read_level():
    ts = items()
    for i, (t, n, e) in enumerate(ts):
        if n == '答卷提示':
            for j in range(len(ts)):
                if ts[j][1] == '评价等级：' and j+1 < len(ts) and ts[j+1][1] in ('A', 'B', 'C'):
                    return ts[j+1][1]
    for t, n, e in ts:
        if n.startswith('[') and ']' in n:
            if '90,100' in n: return 'A'
            if '70,90' in n: return 'B'
            if '0,70' in n: return 'C'
    return None

def answer_one(lv):
    hint = find('Button', '我知道了')
    if hint: act(hint)
    radio = None
    for t, n, e in items():
        if t == 'RadioButton' and n.startswith(lv):
            radio = e; break
    if not radio:
        print('  [FAIL] 找不到整体评价', lv); return False
    sv(radio); act(radio, 'select')
    if lv in ('A', 'C'):
        cbs = [(n, e) for t, n, e in items() if t == 'CheckBox' and not n.startswith('其他')]
        key = '教学态度' if lv == 'A' else '教学效果'
        tgt = next((e for n, e in cbs if n.startswith(key)), cbs[0][1] if cbs else None)
        if tgt:
            sv(tgt); act(tgt, 'toggle')
    sub = None
    for t, n, e in items():
        if t == 'Button' and '提交' in n.replace(' ', ''):
            sub = e; break
    if not sub:
        print('  [FAIL] 找不到提交按钮'); return False
    sv(sub); act(sub)
    time.sleep(5.0)
    for _ in range(5):
        cf = find('Button', '确定')
        if cf: act(cf)
        if find('Text', '提交成功'): return True
        time.sleep(0.8)
    return bool(find('Text', '提交成功'))

def answer_all():
    cnt = 0
    while True:
        nxt = None
        for t, n, e in items():
            if t == 'Text' and n in ('下一门课程', '下一位教师'):
                nxt = e; break
        if not nxt:
            print('没有"下一门"按钮 → 全部完成或尚未开始')
            break
        act(nxt); time.sleep(1.2)
        lv = read_level()
        if not lv:
            print('[FAIL] 读不到等级'); break
        print('第%d门 等级%s' % (cnt+1, lv), flush=True)
        if not answer_one(lv):
            print('[FAIL] 提交失败，停止'); break
        cnt += 1
        if cnt > 50: break
    print('完成', cnt, '门')

if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'check'
    if cmd == 'check':
        ok = check(); print('自检:', '通过' if ok else '未通过'); sys.exit(0 if ok else 1)
    if not check():
        sys.exit(1)
    if cmd == 'select':
        select_levels()
    elif cmd == 'answer':
        answer_all()
    elif cmd == 'all':
        select_levels()
        input('确认并提交等级后回车，开始答卷...')
        answer_all()
    else:
        print('未知命令:', cmd)
        print('用法: python run.py check|select|answer|all')
