# -*- coding: utf-8 -*-
"""评教自动化：颜色识别定位按钮 + 自动点击。用 Python312 + PIL。"""
import ctypes, time, io, sys
from ctypes import wintypes
from PIL import Image
u = ctypes.windll.user32
g = ctypes.windll.gdi32
u.SetProcessDPIAware()
P = ctypes.c_void_p
for f in (u.GetDC, g.CreateCompatibleDC, g.CreateCompatibleBitmap, g.GetStockObject): f.restype = P
for f in (g.DeleteObject, g.DeleteDC): f.argtypes=[P]; f.restype=P
g.SelectObject.argtypes=[P,P]; g.SelectObject.restype=P
g.CreateCompatibleDC.argtypes=[P]
g.CreateCompatibleBitmap.argtypes=[P,ctypes.c_int,ctypes.c_int]
g.BitBlt.argtypes=[P,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,P,ctypes.c_int,ctypes.c_int,ctypes.c_uint]
g.GetDIBits.argtypes=[P,P,ctypes.c_uint,ctypes.c_uint,P,P,ctypes.c_uint]
u.ReleaseDC.argtypes=[P,P]
class BI(ctypes.Structure):
    _fields_=[('biSize',wintypes.DWORD),('biWidth',wintypes.LONG),('biHeight',wintypes.LONG),('biPlanes',wintypes.WORD),('biBitCount',wintypes.WORD),('biCompression',wintypes.DWORD),('biSizeImage',wintypes.DWORD),('biXPelsPerMeter',wintypes.LONG),('biYPelsPerMeter',wintypes.LONG),('biClrUsed',wintypes.DWORD),('biClrImportant',wintypes.DWORD)]

def shot():
    w=u.GetSystemMetrics(0); h=u.GetSystemMetrics(1)
    hdc=u.GetDC(0); bmp=g.CreateCompatibleBitmap(hdc,w,h)
    mdc=g.CreateCompatibleDC(hdc); g.SelectObject(mdc,bmp)
    g.BitBlt(mdc,0,0,w,h,hdc,0,0,0x00CC0020)
    import struct
    bi=BI(); bi.biSize=ctypes.sizeof(BI); bi.biWidth=w; bi.biHeight=h; bi.biPlanes=1; bi.biBitCount=24
    stride=((w*3+3)//4)*4; size=stride*h; buf=ctypes.create_string_buffer(size)
    g.GetDIBits(mdc,bmp,0,h,buf,ctypes.byref(bi),0)
    hdr=struct.pack('<2sIHHI',b'BM',14+40+size,0,0,14)+struct.pack('<IiiHHIIiiII',40,w,h,1,24,0,size,0,0,0,0)
    img=Image.open(io.BytesIO(hdr+buf.raw)).convert('RGB')
    g.DeleteObject(bmp); g.DeleteDC(mdc); u.ReleaseDC(0,hdc)
    return img

def find_color(img, target, tol=25, region=None):
    """找匹配 target RGB 的连通区域，返回 (x,y) 中心。tol 每通道容差。"""
    import numpy as np
    arr=np.asarray(img).astype(int)
    if region:
        x0,y0,x1,y1=region
    else:
        x0,y0,x1,y1=0,0,arr.shape[1],arr.shape[0]
    sub=arr[y0:y1,x0:x1]
    d=np.abs(sub-np.array(target)).max(axis=2)
    mask=d<=tol
    ys,xs=np.where(mask)
    if len(xs)==0: return None
    return (int(x0+xs.mean()), int(y0+ys.mean()), len(xs))

def click(x,y):
    u.SetCursorPos(int(x),int(y)); time.sleep(0.08)
    u.mouse_event(0x0002,0,0,0,0); u.mouse_event(0x0004,0,0,0,0); time.sleep(0.25)

def scroll(n):
    for _ in range(n):
        u.mouse_event(0x0800,0,0,-120,0); time.sleep(0.12)

if __name__=='__main__':
    import numpy as np
    img=shot()
    print('size',img.size)
    # 找绿色按钮 (下一门课程/我知道了): 约 (18,179,124)? 采样
    # 找蓝色按钮 (提交/确定)
    for name,c in [('green',(0,178,80)),('blue',(65,120,240))]:
        r=find_color(img,c,tol=40)
        print(name,r)
